package TDDProject;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Tddproject {

	@Test
	public void findtrainings() {
		String course = "web development";
		int Expectedpractice = 410;
		Trainings pop = new Trainings();
		
		int count = pop.getcoursedata(course);
		System.out.println("the course is: " +course);
		
		Assert.assertEquals(count, Expectedpractice);
	
		
	
	}
	
	@Test
	public void findemptytraining() {
		try {
			String course = "";
			int Expectedpractice = 0;
			Trainings pop = new Trainings();
			int count = pop.getcoursedata(course);
			
	}
	catch(NullPointerException e)
		{
		System.out.println("course name cannot be empty");
		}
	}
	
	@Test
	public void findtraininginvalidinput() {
		try {
			String course = "java";
			int Expectedpractice = 700;
			Trainings pop = new Trainings();
			int count = pop.getcoursedata(course);
		}
		catch(NullPointerException e){
			System.out.println("course name does not exist in the list");
		}
	}
}
