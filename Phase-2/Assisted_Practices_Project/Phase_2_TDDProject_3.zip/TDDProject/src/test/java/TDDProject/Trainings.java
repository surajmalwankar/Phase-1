package TDDProject;


import java.util.HashMap;
import java.util.Map;

	public class Trainings extends Tddproject {

		private Map<String, Integer> courses() {
			
			Map<String, Integer> course_practices  = new HashMap<>();
			course_practices.put("web development", 410);
			course_practices.put("AWS cloud", 250);
			course_practices.put("Machine learning", 100);
			course_practices.put("Data structures", 308);
			
			return course_practices;
		}
		
		public int getcoursedata(String course) {
			Map<String, Integer> course_practices  = null;
			int count = 0;
			
			if(course.isEmpty())
			{
				throw new NullPointerException("Course name cannot be empty");
			}
			course_practices = courses();
			
			if(!course_practices.containsKey(course)) {
				throw new NullPointerException("Course name doesnot exist");
			}
			else {
				count = course_practices.get(course);
			}
			
			return count;
		}


	}

