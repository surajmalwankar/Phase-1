
package com.app.Lesson4EndProject;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)

public class LessonEndProject4 {
	
WebDriver driver;
	
	@BeforeAll
	public void startbrowser()
	{
        driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://www.facebook.com/");
	}
	
	@DisplayName("Lesson 4 project")
	@ParameterizedTest
	@CsvSource({
			"admin, admin@123"
	})
	

public void Testmethod(String username, String pwd) throws InterruptedException
	{
        driver.findElement(By.cssSelector("input#email")).sendKeys(username);
		
	 driver.findElement(By.cssSelector("input[name='pass']")).sendKeys(pwd);
	
	 Thread.sleep(1000);
	
       }
	
	
	
	@AfterAll
	public void closebrowser()
	{
		driver.close();
	}


	@RepeatedTest(2)
	@DisplayName("Lesson 4 project done")
	public void repeatoutput() {
		System.out.println("Facebook Login");
	}
	
	@Test
	public void AssumptionsPractice() {
		boolean isFBServerUp = true;
		Assumptions.assumeTrue(isFBServerUp, "server is not up");
		System.out.println("Login to your Facebook account");
	}
	

}

